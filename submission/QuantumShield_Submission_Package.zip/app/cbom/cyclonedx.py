"""
CycloneDX 1.6 CBOM generator and validator.

Generates a valid CycloneDX 1.6 BOM where every crypto finding becomes a
`cryptographic-asset` component with cryptoProperties, evidence occurrences and
QuantumShield-namespaced properties. Crypto libraries are exported as standard `library`
components (CycloneDX 1.6 has no 'library' crypto assetType, so libraries stay
regular components and reference their crypto via dependencies).

Validation is performed with `jsonschema` against the official CycloneDX 1.6
JSON schema bundled in `schemas/bom-1.6.schema.json`.
"""
import json
import os
import uuid
import datetime
from typing import List

from app.models.crypto_asset import CryptoAsset, AssetType

# Internal primitive -> CycloneDX 1.6 cryptoProperties.primitive enum
PRIMITIVE_MAP = {
    "RSA": "pke",
    "DSA": "signature",
    "ECDSA": "signature",
    "ECDH": "key-agree",
    "DH": "key-agree",
    "X25519": "key-agree",
    "ED25519": "signature",
    "AES": "block-cipher",
    "DES": "block-cipher",
    "DES3": "block-cipher",
    "RC4": "stream-cipher",
    "SHA-256": "hash",
    "SHA-384": "hash",
    "SHA-512": "hash",
    "SHA-1": "hash",
    "SHA1": "hash",
    "MD5": "hash",
    "TLS": "key-agree",
    "DH": "key-agree",
    "BCRYPT": "hash",
    "ARGON2": "kdf",
}

# Internal asset type -> CycloneDX component type
ASSET_TO_COMPONENT = {
    "Algorithm": "cryptographic-asset",
    "Certificate": "cryptographic-asset",
    "Protocol": "cryptographic-asset",
    "Key": "related-crypto-material",
    "Library": "library",  # exported as standard component
}

# quantum status -> nistQuantumSecurityLevel (0-5, source-of-truth model)
def _quantum_level(asset: CryptoAsset) -> int:
    cls = asset.quantum_vuln_class.value
    if cls == "SHOR_BROKEN":
        return 0
    if cls == "GROVER_WEAKENED":
        return 1
    if cls == "QUANTUM_SAFE":
        return 3  # AES-256 / hashes assumed Category 3+; ML-KEM => 3
    if cls == "CLASSICALLY_BROKEN":
        return 0
    return 0


def _cx_primitive(asset: CryptoAsset) -> str:
    p = asset.primitive.upper()
    return PRIMITIVE_MAP.get(p, "other")


def _cx_asset_type(asset: CryptoAsset) -> str:
    t = asset.asset_type.value
    if t == "Library":
        return None
    if t == "Key":
        return "related-crypto-material"
    return "algorithm" if t == "Algorithm" else t.lower()


def _qshield_props(asset: CryptoAsset) -> list:
    props = [
        {"name": "quantumshield:quantum-status", "value": asset.quantum_status.value},
        {"name": "quantumshield:quantum-class", "value": asset.quantum_vuln_class.value},
        {"name": "quantumshield:risk-score", "value": str(asset.risk_score)},
        {"name": "quantumshield:risk-band", "value": asset.risk_band},
        {"name": "quantumshield:confidence", "value": asset.confidence},
    ]
    if asset.mosca_margin is not None:
        props.append({"name": "quantumshield:mosca-margin-years", "value": str(round(asset.mosca_margin, 2))})
        props.append({"name": "quantumshield:mosca-at-risk", "value": str(asset.mosca_at_risk).lower()})
    if asset.recommendation:
        props.append({"name": "quantumshield:recommendation", "value": asset.recommendation})
    if asset.why_risky:
        props.append({"name": "quantumshield:why", "value": asset.why_risky})
    if asset.migration_effort:
        props.append({"name": "quantumshield:effort", "value": asset.migration_effort})
    return props


# CycloneDX 1.6 mode enum
VALID_MODES = {"cbc", "ecb", "ccm", "gcm", "cfb", "ofb", "ctr", "other", "unknown"}

# map common java mode/padding strings to valid CycloneDX mode enum values
MODE_ALIAS = {
    "none": "unknown",
    "nopadding": "unknown",
    "nocipherfeedback": "cfb",
}


def _normalise_mode(mode):
    if not mode:
        return None
    m = mode.strip().lower()
    m = MODE_ALIAS.get(m, m)
    return m if m in VALID_MODES else "other"


def _crypto_properties(asset: CryptoAsset) -> dict:
    """Build cryptoProperties for a cryptographic-asset component."""
    props = {"assetType": _cx_asset_type(asset)}
    algo_props = {}
    if asset.primitive:
        algo_props["primitive"] = _cx_primitive(asset)
    if asset.key_size is not None or str(asset.key_size):
        algo_props["parameterSetIdentifier"] = str(asset.key_size) if asset.key_size else "unknown"
    mode = _normalise_mode(asset.mode)
    if mode:
        algo_props["mode"] = mode
    if asset.padding:
        algo_props["padding"] = asset.padding
    if asset.curve:
        algo_props["curve"] = asset.curve
    algo_props["classicalSecurityLevel"] = 112 if asset.key_size and asset.key_size < 3072 else 128
    algo_props["nistQuantumSecurityLevel"] = _quantum_level(asset)
    props["algorithmProperties"] = algo_props
    return props


def _evidence(asset: CryptoAsset) -> dict:
    return {
        "occurrences": [
            {
                "location": asset.file_path,
                "line": asset.line_number,
                "additionalContext": asset.source_snippet[:500],
            }
        ]
    }


def _component(asset: CryptoAsset) -> dict:
    if asset.asset_type.value == "Library":
        # Standard library component (CycloneDX 1.6 has no library crypto assetType)
        lib_name = asset.library or asset.algorithm
        lib_ver = asset.library_version or "1.0"
        ref = getattr(asset, "cbom_ref", None) or f"lib/{asset.algorithm.lower()}/{lib_name}"
        comp = {
            "type": "library",
            "bom-ref": ref,
            "name": lib_name,
            "version": lib_ver,
        }
        if asset.recommendation:
            comp["properties"] = [
                {"name": "quantumshield:quantum-status", "value": asset.quantum_status.value},
                {"name": "quantumshield:recommendation", "value": asset.recommendation},
            ]
        return comp

    base_ref = getattr(asset, "cbom_ref", None) or f"crypto/{asset.asset_type.value.lower()}/{asset.algorithm.lower()}"
    asset_ref = f"{base_ref}/{asset.asset_id}" if getattr(asset, "asset_id", None) else base_ref

    comp = {
        "type": "cryptographic-asset",
        "name": f"{asset.algorithm}{'-' + str(asset.key_size) if asset.key_size else ''}",
        "bom-ref": asset_ref,
        "cryptoProperties": _crypto_properties(asset),
        "evidence": _evidence(asset),
        "properties": _qshield_props(asset),
    }
    if asset.hndl_risk:
        comp["properties"].append({"name": "quantumshield:threat", "value": "HNDL"})
    if asset.tnfl_risk:
        comp["properties"].append({"name": "quantumshield:threat", "value": "TNFL"})
    return comp


def generate_cyclonedx_cbom(assets: List[CryptoAsset]) -> dict:
    components = []
    seen_refs = set()
    seen_libs = set()

    for a in assets:
        if a.asset_type.value == "Library":
            lib_key = (a.library or a.algorithm, a.library_version or "1.0")
            if lib_key in seen_libs:
                continue
            seen_libs.add(lib_key)
        comp = _component(a)
        ref = comp.get("bom-ref", "")
        if ref in seen_refs:
            ref = f"{ref}_{uuid.uuid4().hex[:6]}"
            comp["bom-ref"] = ref
        seen_refs.add(ref)
        components.append(comp)

    cbom = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.6",
        "serialNumber": f"urn:uuid:{uuid.uuid4()}",
        "version": 1,
        "metadata": {
            "timestamp": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "component": {
                "type": "application",
                "name": "Scanned Target Project",
            }
        },
        "components": components,
    }
    return cbom


def validate_cbom(cbom: dict, schema_path: str = None) -> dict:
    """
    Validate a CBOM dict against the official CycloneDX 1.6 JSON schema.
    Returns {"valid": bool, "errors": [...], "schema": path}.
    """
    import jsonschema
    if schema_path is None:
        base = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        schema_path = os.path.join(base, "schemas", "bom-1.6.schema.json")
    with open(schema_path, "r", encoding="utf-8") as f:
        schema = json.load(f)
    validator = jsonschema.Draft7Validator(schema)
    errors = sorted(validator.iter_errors(cbom), key=lambda e: list(e.path))
    if not errors:
        return {"valid": True, "errors": [], "schema": schema_path}
    return {
        "valid": False,
        "errors": [f"{'/'.join(str(p) for p in e.path) or '<root>'}: {e.message}" for e in errors],
        "schema": schema_path,
    }
